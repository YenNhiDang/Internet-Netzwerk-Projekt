Hier stehen alle Bilder, die wir genutzt haben. Die Datein kann aus .png, .jpeg, usw. sein.
